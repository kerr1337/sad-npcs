@echo off
title Building SadNPCs for Minecraft 26.3...
echo Running Gradle build...
call gradlew.bat build
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Build failed! Check the logs above.
    pause
    exit /b %ERRORLEVEL%
)
echo.
echo [SUCCESS] Build complete! Check build\libs\ for your mod jar.
pause
