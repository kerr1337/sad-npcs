# SadNPCs (`sadnpcs`)

> A Minecraft mod, that adds custom non-player characters (NPCs).

Built for **Minecraft 26.3 (Fabric)** with:
- **Custom NPC Entities** (`SadNpcEntity`) with configurable skins (URL / player username), AI behavior modes (`STAND`, `WANDER`, `FOLLOW`), and built-in in-game GUI editor.
- **Addon System** (`config/sadnpcs/addons/`): Drop `.zip` or folder addons to register custom NPC presets and custom blocks with textures—without writing Java!
- **Custom Blocks**:
  1. **Addon Blocks**: Registered at startup from `blocks/*.json` inside addons.
  2. **Dynamic Custom Block (`sadnpcs:dynamic_block`)**: Placeable block configurable in-game (light level, collision, interactive actions).

## Building
1. Ensure **JDK 21+** is installed.
2. Run `./gradlew build` (or double-click `build.bat` on Windows).
3. Find the compiled `.jar` in `build/libs/`.
