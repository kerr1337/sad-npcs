# sadNPCs 0.2.0 — Block Engine foundation

Fabric mod platform for Minecraft Java Edition 26.3.

## Implemented in this milestone
- Fabric common/client entrypoints.
- Addon entrypoint discovery via Fabric Loader (`sadnpcs` entrypoint).
- Strict JSON block definition validation.
- Duplicate ID detection among config definitions.
- Static registry registration of each valid block and its matching `BlockItem`
  during `ModInitializer`, before registry freeze.
- Collision checks against existing block/item registry keys.
- Per-block generation of blockstate, block model, client item model and loot table
  into an ordinary generated pack directory.
- Optional texture copying from the config texture directory.
- Explicit restart-to-apply workflow.

## Current limits / honest status
- This source has not yet been compiled or launched against Minecraft 26.3.
- Generated pack files are exported to `config/sadnpcs/generated_pack`; Minecraft
  does not automatically mount arbitrary folders as resource/data packs. Enable
  the exported pack as a resource pack and data pack in each world.
- The current model generator emits a simple full cube (`cube_all`). Blockbench
  import, custom geometry and blockstate variants are future work.
- `material` is currently validated metadata; sound, hardness, resistance,
  light, collision and occlusion are applied to the native block.
- `behavior` is validated as an identifier but no behavior provider registry is
  implemented yet. It is intentionally not interpreted as a class name or script.
- The generated loot table uses the default self-drop. Tool tags and custom loot
  rules are not generated yet.
- Namespace for JSON-created blocks is restricted to `sadnpcs`. Addons should
  register Java-defined content in their own namespace through the future API.

## Toolchain
Values follow the current Fabric 26.3 example template / develop page:
- Minecraft 26.3
- Java 25
- Fabric Loader 0.20.1
- Loom 1.19-SNAPSHOT
- Fabric API 0.166.0+26.3
- Gradle wrapper distribution configured to 9.7.1

Build with JDK 25 and Gradle:
`gradle wrapper --gradle-version 9.7.1` (once, if wrapper scripts are absent),
then `./gradlew build`.

## Config paths
- Definitions: `.minecraft/config/sadnpcs/blocks/*.json`
- Textures: `.minecraft/config/sadnpcs/textures/block/*.png`
- Generated pack: `.minecraft/config/sadnpcs/generated_pack/`
