package dev.sadnpcs.client;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-only bootstrap. The in-game editor and key mappings will be registered here.
 */
public final class SadNPCsClient implements ClientModInitializer {
    private static final Logger LOGGER = LoggerFactory.getLogger("sadNPCs");

    @Override
    public void onInitializeClient() {
        LOGGER.info("sadNPCs client systems initialized.");
    }
}
