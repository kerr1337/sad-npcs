package dev.sadnpcs.block;

import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Declarative block description. JSON can select known values only; it cannot
 * name Java classes or execute code.
 */
public record BlockDefinition(
        String id,
        String name,
        String material,
        float hardness,
        float resistance,
        int lightLevel,
        boolean solid,
        boolean transparent,
        String texture,
        String behavior,
        String sound,
        boolean requiresCorrectTool
) {
    private static final Pattern ID_PATTERN =
            Pattern.compile("[a-z0-9_.-]+:[a-z0-9_./-]+");
    private static final Pattern RESOURCE_ID_PATTERN =
            Pattern.compile("[a-z0-9_.-]+:[a-z0-9_./-]+");
    private static final Set<String> MATERIALS =
            Set.of("stone", "wood", "metal", "plant", "wool", "glass", "other");
    private static final Set<String> SOUNDS =
            Set.of("stone", "wood", "metal", "glass", "grass", "wool", "sand");

    public void validate() {
        if (id == null || !ID_PATTERN.matcher(id).matches()) {
            throw new IllegalArgumentException("Invalid block id: " + id);
        }
        String namespace = id.substring(0, id.indexOf(':'));
        if (!namespace.equals("sadnpcs")) {
            throw new IllegalArgumentException(
                    "JSON-defined blocks must use the 'sadnpcs' namespace. Addons register Java content under their own namespace.");
        }
        if (name == null || name.isBlank() || name.length() > 128) {
            throw new IllegalArgumentException("Block name must contain 1-128 characters.");
        }
        if (material == null || !MATERIALS.contains(material.toLowerCase(Locale.ROOT))) {
            throw new IllegalArgumentException("Unsupported material: " + material);
        }
        if (!Float.isFinite(hardness) || hardness < 0 || hardness > 100000) {
            throw new IllegalArgumentException("Hardness must be finite and between 0 and 100000.");
        }
        if (!Float.isFinite(resistance) || resistance < 0 || resistance > 100000) {
            throw new IllegalArgumentException("Resistance must be finite and between 0 and 100000.");
        }
        if (lightLevel < 0 || lightLevel > 15) {
            throw new IllegalArgumentException("Light level must be between 0 and 15.");
        }
        if (texture == null || !RESOURCE_ID_PATTERN.matcher(texture).matches()) {
            throw new IllegalArgumentException("Texture must be a valid resource ID, e.g. sadnpcs:block/magic_stone.");
        }
        if (behavior != null && !behavior.isBlank()
                && !RESOURCE_ID_PATTERN.matcher(behavior).matches()) {
            throw new IllegalArgumentException("Invalid behavior id: " + behavior);
        }
        if (sound == null || !SOUNDS.contains(sound.toLowerCase(Locale.ROOT))) {
            throw new IllegalArgumentException("Unsupported sound: " + sound);
        }
    }
}
