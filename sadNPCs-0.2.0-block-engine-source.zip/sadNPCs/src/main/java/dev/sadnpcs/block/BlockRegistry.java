package dev.sadnpcs.block;

import dev.sadnpcs.SadNPCs;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Registers validated config blocks during ModInitializer, before the game freezes
 * static registries. This is restart-to-apply by design.
 */
public final class BlockRegistry {
    private static final Map<String, Block> REGISTERED = new LinkedHashMap<>();

    private BlockRegistry() {}

    public static void registerAll(Iterable<BlockDefinition> definitions) {
        for (BlockDefinition definition : definitions) {
            try {
                register(definition);
            } catch (RuntimeException exception) {
                SadNPCs.LOGGER.error("Could not register block '{}': {}",
                        definition.id(), exception.getMessage(), exception);
            }
        }
        SadNPCs.LOGGER.info("Registered {}/{} JSON-defined blocks.",
                REGISTERED.size(), count(definitions));
    }

    private static int count(Iterable<BlockDefinition> definitions) {
        int count = 0;
        for (BlockDefinition ignored : definitions) count++;
        return count;
    }

    private static void register(BlockDefinition definition) {
        Identifier id = Identifier.parse(definition.id());
        if (BuiltInRegistries.BLOCK.containsKey(id)) {
            throw new IllegalStateException("Block registry ID is already occupied: " + id);
        }
        if (BuiltInRegistries.ITEM.containsKey(id)) {
            throw new IllegalStateException("Item registry ID is already occupied: " + id);
        }

        ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);

        BlockBehaviour.Properties properties = BlockBehaviour.Properties.of()
                .setId(blockKey)
                .strength(definition.hardness(), definition.resistance())
                .lightLevel(state -> definition.lightLevel());

        if (!definition.solid()) properties.noCollision();
        if (definition.transparent()) properties.noOcclusion();
        if (definition.requiresCorrectTool()) properties.requiresCorrectToolForDrops();
        properties.sound(soundType(definition.sound()));

        Block block = Registry.register(
                BuiltInRegistries.BLOCK,
                blockKey,
                new Block(properties)
        );

        Item.Properties itemProperties = new Item.Properties()
                .setId(itemKey)
                .useBlockDescriptionPrefix();

        Registry.register(
                BuiltInRegistries.ITEM,
                itemKey,
                new BlockItem(block, itemProperties)
        );

        REGISTERED.put(definition.id(), block);
        BlockResourcePackGenerator.generate(definition);
        SadNPCs.LOGGER.info("Registered block and BlockItem '{}'.", definition.id());
    }

    private static SoundType soundType(String sound) {
        return switch (sound) {
            case "wood" -> SoundType.WOOD;
            case "metal" -> SoundType.METAL;
            case "glass" -> SoundType.GLASS;
            case "grass" -> SoundType.GRASS;
            case "wool" -> SoundType.WOOL;
            case "sand" -> SoundType.SAND;
            default -> SoundType.STONE;
        };
    }

    public static Map<String, Block> getRegisteredBlocks() {
        return Map.copyOf(REGISTERED);
    }
}
