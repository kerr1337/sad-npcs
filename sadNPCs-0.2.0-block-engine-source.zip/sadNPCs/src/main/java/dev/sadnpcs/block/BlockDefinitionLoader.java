package dev.sadnpcs.block;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.sadnpcs.SadNPCs;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/** Loads and validates JSON block definitions before registry construction. */
public final class BlockDefinitionLoader {
    private static final Gson GSON = new GsonBuilder().create();
    private static final Path DIRECTORY = FabricLoader.getInstance()
            .getConfigDir().resolve("sadnpcs").resolve("blocks");

    private BlockDefinitionLoader() {}

    public static List<BlockDefinition> loadAll() {
        List<BlockDefinition> definitions = new ArrayList<>();
        Set<String> ids = new HashSet<>();

        try {
            Files.createDirectories(DIRECTORY);
            try (Stream<Path> files = Files.list(DIRECTORY)) {
                files.filter(path -> path.getFileName().toString().endsWith(".json"))
                        .sorted()
                        .forEach(path -> loadOne(path, definitions, ids));
            }
        } catch (IOException exception) {
            SadNPCs.LOGGER.error("Could not read block definitions from {}.", DIRECTORY, exception);
        }

        SadNPCs.LOGGER.info("Validated {} block definition(s).", definitions.size());
        return List.copyOf(definitions);
    }

    private static void loadOne(Path path, List<BlockDefinition> output, Set<String> ids) {
        try (var reader = Files.newBufferedReader(path)) {
            BlockDefinition definition = GSON.fromJson(reader, BlockDefinition.class);
            if (definition == null) throw new IllegalArgumentException("JSON file is empty.");
            definition.validate();
            if (!ids.add(definition.id())) {
                throw new IllegalArgumentException("Duplicate block id: " + definition.id());
            }
            output.add(definition);
        } catch (Exception exception) {
            SadNPCs.LOGGER.error("Skipping block definition '{}': {}",
                    path.getFileName(), exception.getMessage());
        }
    }
}
