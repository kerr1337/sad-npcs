package dev.sadnpcs.api.addon;

/**
 * Entry point implemented by third-party sadNPCs addons.
 *
 * Addons should register content and behavior during onInitialize.
 * Keep client-only classes out of this common entrypoint.
 */
public interface SadNPCsAddon {
    /**
     * Called once during sadNPCs startup after core configuration discovery.
     */
    void onInitialize(SadNPCsAddonContext context);
}
