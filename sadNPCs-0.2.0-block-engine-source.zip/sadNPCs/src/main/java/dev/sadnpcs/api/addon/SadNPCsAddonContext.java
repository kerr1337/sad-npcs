package dev.sadnpcs.api.addon;

import org.slf4j.Logger;

/**
 * Narrow public surface exposed to addons. This will grow through versioned API
 * interfaces rather than exposing sadNPCs implementation internals.
 */
public interface SadNPCsAddonContext {
    String getModId();

    Logger getLogger();
}
