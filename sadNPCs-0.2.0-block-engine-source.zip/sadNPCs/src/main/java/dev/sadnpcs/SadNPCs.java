package dev.sadnpcs;

import dev.sadnpcs.addon.AddonLoader;
import dev.sadnpcs.block.BlockDefinitionLoader;
import dev.sadnpcs.block.BlockRegistry;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class SadNPCs implements ModInitializer {
    public static final String MOD_ID = "sadnpcs";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Starting sadNPCs {}...", "0.2.0");

        // Addons initialize first so future behavior providers can be registered.
        AddonLoader.loadAll();

        // JSON is validated, then registered before static registries are frozen.
        var definitions = BlockDefinitionLoader.loadAll();
        BlockRegistry.registerAll(definitions);

        LOGGER.info("sadNPCs core initialization complete.");
    }
}
