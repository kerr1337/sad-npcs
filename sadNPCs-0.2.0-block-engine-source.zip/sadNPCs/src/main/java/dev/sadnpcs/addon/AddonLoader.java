package dev.sadnpcs.addon;

import dev.sadnpcs.SadNPCs;
import dev.sadnpcs.api.addon.SadNPCsAddon;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Discovers addon entrypoints declared by installed Fabric mods.
 * Fabric Loader handles jar discovery, dependency resolution and classloading.
 */
public final class AddonLoader {
    private AddonLoader() {
    }

    public static void loadAll() {
        var entrypoints = FabricLoader.getInstance()
                .getEntrypointContainers("sadnpcs", SadNPCsAddon.class);

        for (var entrypoint : entrypoints) {
            String modId = entrypoint.getProvider().getMetadata().getId();
            try {
                entrypoint.getEntrypoint().onInitialize(new DefaultAddonContext(modId));
                SadNPCs.LOGGER.info("Loaded addon entrypoint from '{}'.", modId);
            } catch (Throwable error) {
                SadNPCs.LOGGER.error("Addon '{}' failed during initialization.", modId, error);
            }
        }

        SadNPCs.LOGGER.info("Discovered {} sadNPCs addon entrypoint(s).", entrypoints.size());
    }
}
