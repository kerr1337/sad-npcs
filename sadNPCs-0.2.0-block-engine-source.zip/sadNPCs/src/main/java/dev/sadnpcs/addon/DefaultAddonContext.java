package dev.sadnpcs.addon;

import dev.sadnpcs.SadNPCs;
import dev.sadnpcs.api.addon.SadNPCsAddonContext;
import org.slf4j.Logger;

final class DefaultAddonContext implements SadNPCsAddonContext {
    private final String modId;

    DefaultAddonContext(String modId) {
        this.modId = modId;
    }

    @Override
    public String getModId() {
        return modId;
    }

    @Override
    public Logger getLogger() {
        return SadNPCs.LOGGER;
    }
}
