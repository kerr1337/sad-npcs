# sadNPCs architecture — 0.2.0

## Startup lifecycle
1. Fabric Loader resolves mods and addon dependencies.
2. `SadNPCs.onInitialize` runs.
3. `AddonLoader` invokes registered `sadnpcs` entrypoints.
4. `BlockDefinitionLoader` parses and validates all config JSON.
5. `BlockRegistry` checks IDs and registers each block and `BlockItem`.
6. `BlockResourcePackGenerator` exports blockstate/model/client-item/loot JSON.
7. Client initializer starts client-only systems.

## Registry safety
- Definitions are loaded before any registry writes.
- IDs must be valid namespaced identifiers and config-defined IDs must use
  `sadnpcs:`; addons own their own namespaces.
- Duplicate config IDs are rejected.
- Existing block and item keys are checked before registration.
- Properties are built with the matching `ResourceKey` before registry insertion.
- Registration failures are isolated per definition and logged.
- Registry writes happen only during mod initialization. Never reload definitions
  into the live registry after startup.

## Resource/data output
The generated pack is an ordinary vanilla pack under
`config/sadnpcs/generated_pack`. Minecraft does not auto-discover arbitrary
directories as packs. The user must enable the resource pack and data pack in
the world. A later milestone should implement pack auto-discovery/integration
using the supported 26.3 pack APIs and world lifecycle.

## Addon contract
Fabric Loader owns jar discovery, dependencies and classloading. Third-party
addons use the `sadnpcs` entrypoint. JSON may refer to a namespaced behavior ID;
the future Java API will register behavior factories for those IDs. Never use
reflection to instantiate arbitrary classes from JSON.

## Future
- Behavior provider registry and addon registration phases.
- Automatic pack discovery and data-pack activation.
- Tool tags, custom loot rules, recipes and translations.
- Blockbench model conversion and model validation.
- Item Engine and in-game editor.
