# Example addon entrypoint

Add this class to a separate Fabric mod and declare the `sadnpcs` entrypoint
in that mod's `fabric.mod.json`.

```java
package example.addon;

import dev.sadnpcs.api.addon.SadNPCsAddon;
import dev.sadnpcs.api.addon.SadNPCsAddonContext;

public final class ExampleAddon implements SadNPCsAddon {
    @Override
    public void onInitialize(SadNPCsAddonContext context) {
        context.getLogger().info("Hello from addon: {}", context.getModId());
    }
}
```

The public API is intentionally small in 0.1.0. Block/item/NPC registration
interfaces will be introduced as their lifecycle and validation contracts land.
