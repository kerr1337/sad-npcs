# User content

Copy `blocks/magic_stone.json` to `.minecraft/config/sadnpcs/blocks/`.
Place the corresponding PNG texture at:

` .minecraft/config/sadnpcs/textures/block/magic_stone.png `

The resource/data pack is exported to `.minecraft/config/sadnpcs/generated_pack`.
Enable it as a resource pack and, for loot tables, as a datapack in each world.
Changes to block definitions require a full game restart because block/item
registries are static and frozen during startup.
